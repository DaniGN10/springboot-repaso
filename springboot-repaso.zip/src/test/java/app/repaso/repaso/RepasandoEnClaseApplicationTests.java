package app.repaso.repaso;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepasandoEnClaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
