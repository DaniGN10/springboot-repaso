package app.repaso.repaso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepasandoEnClaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepasandoEnClaseApplication.class, args);
	}

}
