package app.repaso.repaso.repositories;

import app.repaso.repaso.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RolRepository extends JpaRepository<Long, Role> {
}
