package app.repaso.repaso.repositories;

import app.repaso.repaso.model.Empleado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmpleadoRepository extends JpaRepository<Long,Empleado> {
}
