package app.repaso.repaso.services;

import app.repaso.repaso.model.Equipo;
import app.repaso.repaso.model.Personaje;
import app.repaso.repaso.repositories.EquipoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class EquipoService {

    @Autowired
    private final EquipoRepository equipoRepository;


    public EquipoService(EquipoRepository equipoRepository) {
        this.equipoRepository = equipoRepository;
    }

    public List<Equipo> findAllEquipos(){
        return equipoRepository.findAll();
    }

    public List<Personaje> findByEquipo(String equipo){
        Optional<Equipo> equipo1 = this.equipoRepository.findByNombre(equipo);

        if(!equipo1.isEmpty() && equipo1.isPresent()){
            return equipo1.get().getPersonajes();
        }
        else{
            return new ArrayList<>();
        }
    }
    public Equipo crearEquipo(String nombre, String fundador, Integer anio_fundacion) {
        Equipo equipo = new Equipo();
        equipo.setNombre(nombre);

        if (!fundador.isEmpty()) {
            equipo.setFundador(fundador);
        }

        equipo.setAnioFundacion(anio_fundacion);

        return this.equipoRepository.save(equipo);
    }

}
