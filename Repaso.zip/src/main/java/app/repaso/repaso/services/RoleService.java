package app.repaso.repaso.services;

import app.repaso.repaso.model.Empleado;
import app.repaso.repaso.model.Role;
import app.repaso.repaso.repositories.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class RoleService {

    @Autowired
    private RoleRepository roleRepository;

    public List<Role> findAll() {
        return this.roleRepository.findAll();
    }

    public List<Empleado> filterEmpleadoByRole(String nombreRol) {
       Optional<Role> role = this.roleRepository.findByNombre(nombreRol);

       if (role.isPresent()) {
           return role.get().getEmpleados();
       }
       else {
           return new ArrayList<>();
       }
    }

    public void crearRole(String nombre, String desc) {
        Role role = new Role();
        role.setNombre(nombre);

        if (!desc.isEmpty()) {
            role.setDescripcion(desc);
        }
        this.roleRepository.save(role);
    }
}
