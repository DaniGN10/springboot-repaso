package app.repaso.repaso.dto;

public class PersonajeRequest {

    private String nombre;
    private String alias;
    private String poder;
    private String universo;
    private Long equipo_id;

    public PersonajeRequest(String nombre, String alias, String poder, String universo, Long equipo_id) {
        this.nombre = nombre;
        this.alias = alias;
        this.poder = poder;
        this.universo = universo;
        this.equipo_id = equipo_id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getPoder() {
        return poder;
    }

    public void setPoder(String poder) {
        this.poder = poder;
    }

    public String getUniverso() {
        return universo;
    }

    public void setUniverso(String universo) {
        this.universo = universo;
    }

    public Long getEquipo_id() {
        return equipo_id;
    }

    public void setEquipo_id(Long equipo_id) {
        this.equipo_id = equipo_id;
    }
}
