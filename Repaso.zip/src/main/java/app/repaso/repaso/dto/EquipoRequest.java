package app.repaso.repaso.dto;

public class EquipoRequest {

    private String nombre;
    private String fundador;
    private Integer anioFundacion;

    public EquipoRequest(String nombre, String fundador, Integer anioFundacion) {
        this.nombre = nombre;
        this.fundador = fundador;
        this.anioFundacion = anioFundacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFundador() {
        return fundador;
    }

    public void setFundador(String fundador) {
        this.fundador = fundador;
    }

    public Integer getAnioFundacion() {
        return anioFundacion;
    }

    public void setAnioFundacion(Integer anioFundacion) {
        this.anioFundacion = anioFundacion;
    }
}
