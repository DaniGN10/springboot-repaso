package app.repaso.repaso.model;


import jakarta.persistence.*;

import java.util.List;

//Esto debe de ser una tabla en mi base de datos y esta tabla se debe llamar roles.
//Las columnas que debe tener son:
// - id
// - nombre (debe de ser único y no puede estar vacío)
// - despcripción (puede estar vacía, ya que es opcional) y la columna se debe llamar desc
@Entity
@Table(name = "roles")
public class Role {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String nombre;

    @Column(name = "desc", nullable = false)
    private String descripcion;

    @OneToMany(mappedBy = "role")
    private List<Empleado> empleados;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public void setEmpleados(List<Empleado> empleados) {
        this.empleados = empleados;
    }
}
