package app.repaso.repaso.controller;

import app.repaso.repaso.model.Equipo;
import app.repaso.repaso.model.Personaje;
import app.repaso.repaso.services.EquipoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/equipo")
public class EquipoController {

    @Autowired
    private EquipoService equipoService;

    @GetMapping("/todos")
    public ResponseEntity<List<Equipo>> findAllEquipos(){
        return ResponseEntity.ok(this.equipoService.findAllEquipos());
    }

    @GetMapping("/nombre/{nbr}")
    public ResponseEntity<List<Personaje>> findByEquipo(@PathVariable String nbr){
        return ResponseEntity.ok(this.equipoService.findByEquipo(nbr));
    }

    @PostMapping("/create")
    public ResponseEntity<Equipo> crearEquipo(Equipo equipo){
        return ResponseEntity.ok(this.equipoService.crearEquipo(
                equipo.getNombre(),
                equipo.getFundador(),
                equipo.getAnioFundacion()
        ));
    }
}
