package app.repaso.repaso.controller;

import app.repaso.repaso.dto.PersonajeRequest;
import app.repaso.repaso.model.Personaje;
import app.repaso.repaso.services.PersonajeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/personajes") // https://www.URL.com/api/personajes
public class PersonajeController {

    @Autowired
    private PersonajeService personajeService;

    @GetMapping("/obtener") // https://www.URL.com/api/personajes/obtener
    public ResponseEntity<List<Personaje>> findAllPersonajes() {
        return ResponseEntity.ok(this.personajeService.obtenerPersonajes());
    }

    @PostMapping("/nombre") // https://www.URL.com/api/personajes/nombre
    public ResponseEntity<Optional<Personaje>> findByNombre(@RequestParam String nombre) {
        return ResponseEntity.ok(this.personajeService.findByNombre(nombre));
    }

    @GetMapping("/poder/{pdr}") // https://www.URL.com/api/personajes/poder/{---}
    public ResponseEntity<List<Personaje>> findByPoder(@PathVariable String pdr) {
        return ResponseEntity.ok(this.personajeService.findByPoder(pdr));
    }

    @PostMapping("/create") // https://www.URL.com/api/personajes/create
    public void crearPersonaje(@RequestBody PersonajeRequest personaje) {
        this.personajeService.crearPersonaje(
                personaje.getNombre(),
                personaje.getAlias(),
                personaje.getPoder(),
                personaje.getUniverso(),
                personaje.getEquipo_id()
        );
    }
}
