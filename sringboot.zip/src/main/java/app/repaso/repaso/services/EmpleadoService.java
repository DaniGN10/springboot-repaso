package app.repaso.repaso.services;

import app.repaso.repaso.model.Empleado;
import app.repaso.repaso.model.Role;
import app.repaso.repaso.repositories.EmpleadoRepository;
import app.repaso.repaso.repositories.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmpleadoService {

    @Autowired
    private EmpleadoRepository empleadoRepository;

    @Autowired
    private RoleRepository roleRepository;

    public List<Empleado> findAll() {
        return this.empleadoRepository.findAll();
    }

    public Optional<Empleado> findById(Long id) {
        Optional<Empleado> empleado = this.empleadoRepository.findById(id);
        return empleado;
        //Empleado empleado = this.empleadoRepository.findById(id).orElseThrow(
        //      () -> new IllegalArgumentException("No existe el empleado buscado")
        // );
        //return Optional.ofNullable(empleado);
    }

    public Optional<Empleado> findByNombre(String nombre) {
        Optional<Empleado> empleado = this.empleadoRepository.findByNombre(nombre);
        return empleado;
    }

    public void crearEmpleado(String nombre, long role_id) {
        Empleado empleado = new Empleado();
        empleado.setNombre(nombre);

        Optional<Role> role = this.roleRepository.findById(role_id);
            if (role.isPresent()) {
                empleado.setRole(role.get() );
            }
            else {
                throw new IllegalArgumentException("No existe el Role que has pasado");
            }
    }
}
