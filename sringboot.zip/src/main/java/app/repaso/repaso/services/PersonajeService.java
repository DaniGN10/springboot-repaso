package app.repaso.repaso.services;

import app.repaso.repaso.model.Personaje;
import app.repaso.repaso.repositories.PersonajeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class PersonajeService {

    @Autowired
    private PersonajeRepository personajeRepository;

    public List<Personaje> obtenerPersonajes() {
       return this.personajeRepository.findAll();
    }

    public Optional<Personaje> findByNombre(String nombre) {

        return this.personajeRepository.findByNombre(nombre);
    }

    public List<Personaje> findByPoder(String poder) {
        List<Personaje> personajes = this.obtenerPersonajes();
        List<Personaje> personajes1 = new ArrayList<>();

        if (personajes.isEmpty()) {
            for (int i = 0; i < personajes.size(); i++) {
                if (personajes.get(i).getPoder().equals(poder)) {
                    personajes1.add(personajes.get(i));
                }
            }
        }

        return personajes1;
    }

    public void crearPersonaje(String nombre, String alias, String poder, String universo, String equipo_id) {
        Personaje personaje = new Personaje();
        personaje.setNombre(nombre);
        personaje.setAlias(alias);
        personaje.setPoder(poder);
        personaje.setUniverso(universo);

        if (!equipo_id.isEmpty()) {
            personaje.setEquipo(equipo_id);
        }
        this.personajeRepository.save(personaje);
    }
}
